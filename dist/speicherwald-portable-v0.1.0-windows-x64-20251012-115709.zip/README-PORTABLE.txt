SpeicherWald – Portable Build

Start: RUN-SpeicherWald.cmd (öffnet Browser) oder direkt speicherwald.exe.
Web-UI: http://127.0.0.1:8080/

Optional (falls enthalten): speicherwald-desktop.exe oder RUN-Desktop.cmd für die Desktop-GUI.

Datenbank: ./data/speicherwald.db (wird beim Start angelegt).
Konfiguration (optional): speicherwald.toml im gleichen Ordner.
